const http = require('http');
const { exec } = require('child_process');
const path = require('path');

// Create the HTTP server
const server = http.createServer((req, res) => {
  const { pathname, searchParams } = new URL(req.url, `http://${req.headers.host}`);
const key = searchParams.get('key');
const host = searchParams.get('host');
const port = searchParams.get('port');
const time = searchParams.get('time');
const method = searchParams.get('method');

// Check if the key is correct
  if (!key) {
    res.statusCode = 403;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ result: 'error', message: 'Missing key' }));
    return;
  } else if (key !== 'zrawh') {
    res.statusCode = 403;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ result: 'error', message: 'Invalid key' }));
    return;
  } else if (!method) {
    res.statusCode = 403;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ result: 'error', message: 'Missing method' }));
    return;
  }

  // Construct the file path based on the method
  const filePath = path.join(__dirname, `${method}.js`);

  switch (method) {
    case 'tls':
	  if (!host || !time) {
        res.statusCode = 400;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ result: 'error', message: 'Bad Request (missing parameter)' }));
        return;
      }
	  res.statusCode = 200;
	  res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ result: 'success', host: `${host}`, time: `${time}`, method:` ${method}` }));
      exec(`node ${filePath} ${host} ${time}`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error executing ${method}.js: ${error.message}`);
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ result: 'error', message: 'Internal Server Error' }));
        }
      });
      break;
    case 'cf':
	   if (!host || !time) {
        res.statusCode = 400;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ result: 'error', message: 'Bad Request (missing parameter)' }));
        return;
      }
	  res.statusCode = 200;
	  res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ result: 'success', host: `${host}`, time: `${time}`, method:` ${method}` }));
      exec(`node ${filePath} ${host} ${time}`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error executing ${method}.js: ${error.message}`);
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ result: 'error', message: 'Internal Server Error' }));
        }
      });
      break;
	case 'hulk':
	  if (!host || !time) {
        res.statusCode = 400;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ result: 'error', message: 'Bad Request (missing parameter)' }));
        return;
      }
	  res.statusCode = 200;
	  res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ result: 'success', host: `${host}`, time: `${time}`, method:` ${method}` }));
      exec(`go run hulk.go -timeout ${time} ${host}`, (error, stdout, stderr) => {
        if (error) {
          console.error(`Error executing ${method}.js: ${error.message}`);
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ result: 'error', message: 'Internal Server Error' }));
        }
      });
      break;
    default:
      res.statusCode = 400;
      res.end('Bad Request');
      break;
  }
});

// Start the server
const portserver = 80;
server.listen(portserver, () => {
  console.log(`Server running on port ${portserver}`);
});
